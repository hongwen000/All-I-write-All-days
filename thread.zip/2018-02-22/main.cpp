#include <mutex>
#include <functional>
#include <thread>
#include "moduleA.h"
#include "moduleB.h"
int main()
{
	//Shared variable
    double var = 0;
    //The lock
    std::mutex mut;
    //Instantiate two modules
    A a;
    B b;
    //Start two threads
    std::thread threadA(a,std::ref(var),std::ref(mut));
    std::thread threadB(b,std::ref(var),std::ref(mut));
    //Wait for threads end
    threadA.join();
    threadB.join();
}
