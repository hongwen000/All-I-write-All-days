#include <iostream>
#include <mutex>
class A {
    public:
    	//Constructor
    	A() {
    		std::cout << "Initing Module A" << std::endl;
    	}
    	//Thread function
    	void operator()(double& var, std::mutex& mut);
    	//Function that W/R on shared variable
        void funcA(double& var, std::mutex& mut);
};
