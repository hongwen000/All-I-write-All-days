#include "moduleB.h"
void B::operator()(double& var, std::mutex& mut) {
	funcB(var,mut);
}
void B::funcB(double& var, std::mutex& mut){
	//Lock the mutex
    std::lock_guard<std::mutex> lock(mut);
    for (int i = 0; i < 10; i++) {
    	var = var - 1;
    	std::cout << "In thread B, var is:" << var << std::endl;
    }
    //The mutex automaticly unlocks when lock_guard is deconstructed
    //You can call mut.unlock() to manually uncock
}
