#include <iostream>
#include <mutex>
class B {
    public:
    	//Constructor
    	B() {
    		std::cout << "Initing Module B" << std::endl;
    	}
    	//Thread function
    	void operator()(double& var, std::mutex& mut);
    	//Function that W/R on shared variable
        void funcB(double& var, std::mutex& mut);
};
